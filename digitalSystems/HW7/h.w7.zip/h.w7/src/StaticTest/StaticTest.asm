//C_PUSH constant 111
@111
D=A
@SP
A=M
M=D
@SP
M=M+1
//C_PUSH constant 333
@333
D=A
@SP
A=M
M=D
@SP
M=M+1
//C_PUSH constant 888
@888
D=A
@SP
A=M
M=D
@SP
M=M+1
//C_POP static 8
@SP
M=M-1
A=M
D=M
@StaticTest8
M=D
//C_POP static 3
@SP
M=M-1
A=M
D=M
@StaticTest3
M=D
//C_POP static 1
@SP
M=M-1
A=M
D=M
@StaticTest1
M=D
//C_PUSH static 3
@StaticTest3
D=M
@SP
A=M
M=D
@SP
M=M+1
//C_PUSH static 1
@StaticTest1
D=M
@SP
A=M
M=D
@SP
M=M+1
//sub
@SP
M=M-1
A=M
D=M
@SP
M=M-1
A=M
M=M-D
@SP
M=M+1
//C_PUSH static 8
@StaticTest8
D=M
@SP
A=M
M=D
@SP
M=M+1
//add
@SP
M=M-1
A=M
D=M
@SP
M=M-1
A=M
M=D+M
@SP
M=M+1
(END)
@END
0;JMP